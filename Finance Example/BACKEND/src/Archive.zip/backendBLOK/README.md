# Backend for Financial BlockChain Written in Golang

##As of Feb 20 this is a bit messy, will refactor shortly
- Also let me know where comments are needed for the hackathon attendees.

##Relies on Two packages gorilla/mux and rs/cors
- To install `go get -u github.com/gorilla/mux` and `go get github.com/rs/cors`
- Depending on installation make sure to change path in either `bash_profile` or in main.go
