package globals

//GlobalStockPrice holds the global stock price
var GlobalStockPrice float64
var GlobalStockSymbol = "foobar"
